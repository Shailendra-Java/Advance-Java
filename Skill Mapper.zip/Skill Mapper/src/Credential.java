
public class Credential {
	private static final String PASSWORD = "tjkjgh!ght";
	
	public static String getPassword(){
		return PASSWORD;
	}
}
