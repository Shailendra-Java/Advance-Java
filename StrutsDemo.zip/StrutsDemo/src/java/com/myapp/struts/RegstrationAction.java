package com.myapp.struts;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class RegstrationAction extends Action
{
    private static final String SUCCESS = "success";
    private static final String ERROR = "error";
    
    @Override
    public ActionForward execute(ActionMapping actionMapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    
       RegistrationForm registrationForm = (RegistrationForm) actionForm;
       String userName = registrationForm.getUserName();
       String password1 = registrationForm.getPass1();
       String password2 = registrationForm.getPass2();
       
       if(password1.equals(password2))
           return actionMapping.findForward(SUCCESS);
       else
           return actionMapping.findForward(ERROR);
    }
}
